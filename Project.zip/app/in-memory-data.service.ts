import { InMemoryDbService } from 'angular-in-memory-web-api';
export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    let heroes = [
      {id: 11, name: 'Cosmology'},
      {id: 12, name: 'Physics'},
      {id: 13, name: 'Mathematics'},
      {id: 14, name: 'Verbal'},
      {id: 15, name: 'puzzles'},
      {id: 16, name: 'economics'},
      {id: 17, name: 'History'},
      {id: 18, name: 'DBMS'},
      {id: 19, name: 'Modeling'},
      {id: 20, name: 'Networks}
    ];
    return {heroes};
  }
}


/*
Copyright 2017 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/